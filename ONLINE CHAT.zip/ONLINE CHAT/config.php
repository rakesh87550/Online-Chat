<?php

$dbHost ='localhost';
$dbUsername ='root';
$dbPassword ='65213290';
$dbDatabase ='tutorial_db';
$conn=mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbDatabase);

?>